CREATE SCHEMA hardcharger_rbac;
CREATE SCHEMA instr;
CREATE TABLE hardcharger_rbac.catalog_tenants (
    catalog_key character varying NOT NULL,
    catalog_name character varying NOT NULL,
    tenant_id character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.group_mappings (
    mapping_id character varying NOT NULL,
    issuer character varying NOT NULL,
    group_name character varying NOT NULL,
    role_id character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.mask_bindings (
    table_key character varying NOT NULL,
    column_key character varying NOT NULL,
    catalog_name character varying NOT NULL,
    schema_path character varying NOT NULL,
    object_name character varying NOT NULL,
    column_name character varying NOT NULL,
    policy_id character varying NOT NULL,
    exempt_role_ids character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.masking_policies (
    policy_id character varying NOT NULL,
    name character varying NOT NULL,
    name_key character varying NOT NULL,
    parameter character varying NOT NULL,
    parameter_type character varying NOT NULL,
    return_type character varying NOT NULL,
    body character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.memberships (
    member_kind character varying NOT NULL,
    member_id character varying NOT NULL,
    role_id character varying NOT NULL,
    admin_option boolean NOT NULL,
    granted_by character varying
);
CREATE TABLE hardcharger_rbac.meta (
    key character varying NOT NULL,
    value character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.object_grants (
    grant_id character varying NOT NULL,
    role_id character varying NOT NULL,
    scope character varying NOT NULL,
    catalog_name character varying NOT NULL,
    schema_path character varying NOT NULL,
    object_name character varying NOT NULL,
    privilege character varying NOT NULL,
    columns character varying NOT NULL,
    grant_option boolean NOT NULL,
    granted_by character varying
);
CREATE TABLE hardcharger_rbac.owners (
    object_key character varying NOT NULL,
    catalog_name character varying NOT NULL,
    schema_path character varying NOT NULL,
    object_name character varying NOT NULL,
    object_type character varying NOT NULL,
    owner_kind character varying NOT NULL,
    owner_id character varying NOT NULL,
    definition_hash character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.principal_tenants (
    principal_kind character varying NOT NULL,
    principal_id character varying NOT NULL,
    tenant_id character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.roles (
    role_id character varying NOT NULL,
    name character varying NOT NULL,
    name_key character varying NOT NULL,
    builtin boolean NOT NULL
);
CREATE TABLE hardcharger_rbac.row_policies (
    policy_id character varying NOT NULL,
    name character varying NOT NULL,
    table_key character varying NOT NULL,
    catalog_name character varying NOT NULL,
    schema_path character varying NOT NULL,
    object_name character varying NOT NULL,
    permissive boolean NOT NULL,
    role_ids character varying NOT NULL,
    predicate character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.scoped_tokens (
    token_id character varying NOT NULL,
    name character varying NOT NULL,
    name_key character varying NOT NULL,
    user_id character varying NOT NULL,
    parent_id character varying NOT NULL,
    privileges character varying NOT NULL,
    catalogs character varying NOT NULL,
    expires_at character varying NOT NULL,
    created_by character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.storage_privileges (
    role_id character varying NOT NULL,
    privilege character varying NOT NULL,
    location character varying NOT NULL,
    admin_option boolean NOT NULL,
    granted_by character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.system_privileges (
    role_id character varying NOT NULL,
    privilege character varying NOT NULL,
    admin_option boolean NOT NULL,
    granted_by character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.tenants (
    tenant_id character varying NOT NULL,
    name character varying NOT NULL,
    name_key character varying NOT NULL,
    default_catalog character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.user_attributes (
    user_id character varying NOT NULL,
    attribute character varying NOT NULL,
    value character varying NOT NULL
);
CREATE TABLE hardcharger_rbac.users (
    user_id character varying NOT NULL,
    name character varying NOT NULL,
    name_key character varying NOT NULL,
    password_hash character varying,
    enabled boolean NOT NULL
);
CREATE TABLE instr.instances (
    instance_id uuid NOT NULL,
    cluster_id uuid,
    hardcharger_version character varying NOT NULL,
    duckdb_version character varying NOT NULL,
    arrow_version character varying NOT NULL,
    hostname character varying,
    hostname_arg character varying,
    server_ip character varying,
    port integer,
    database_path character varying,
    tls_enabled boolean NOT NULL,
    tls_cert_path character varying,
    tls_key_path character varying,
    mtls_required boolean NOT NULL,
    mtls_ca_cert_path character varying,
    readonly boolean NOT NULL,
    os_platform character varying,
    os_name character varying,
    os_version character varying,
    cpu_arch character varying,
    cpu_model character varying,
    cpu_count integer,
    memory_total_bytes bigint,
    start_time timestamp with time zone NOT NULL,
    stop_time timestamp with time zone,
    status character varying NOT NULL,
    stop_reason character varying,
    instance_tag json
);
CREATE TABLE instr.sessions (
    session_id character varying NOT NULL,
    instance_id uuid NOT NULL,
    username character varying NOT NULL,
    role character varying NOT NULL,
    auth_method character varying NOT NULL,
    peer character varying NOT NULL,
    peer_identity character varying,
    user_agent character varying,
    connection_protocol character varying NOT NULL,
    start_time timestamp with time zone NOT NULL,
    stop_time timestamp with time zone,
    status character varying NOT NULL,
    stop_reason character varying,
    session_tag json
);
CREATE VIEW instr.active_sessions AS
 SELECT s.session_id,
    s.instance_id,
    s.username,
    s.role,
    s.auth_method,
    s.peer,
    s.peer_identity,
    s.user_agent,
    s.connection_protocol,
    s.start_time,
    s.status,
    i.hostname,
    i.hostname_arg,
    i.server_ip,
    i.port,
    i.database_path,
    s.session_tag,
    i.instance_tag,
    EXTRACT(epoch FROM (now() - s.start_time)) AS session_duration_seconds,
    i.cluster_id
   FROM (instr.sessions s
     JOIN instr.instances i ON ((s.instance_id = i.instance_id)))
  WHERE (((s.status)::text = 'active'::text) AND ((i.status)::text = 'running'::text));
CREATE TABLE instr.sql_executions (
    execution_id character varying NOT NULL,
    statement_id character varying NOT NULL,
    bind_parameters character varying,
    execution_start_time timestamp with time zone NOT NULL,
    execution_end_time timestamp with time zone,
    enqueue_time timestamp with time zone,
    fetch_start_time timestamp with time zone,
    fetch_end_time timestamp with time zone,
    cursor_close_time timestamp with time zone,
    rows_fetched bigint,
    status character varying NOT NULL,
    error_message character varying,
    duration_ms bigint,
    total_duration_ms bigint,
    query_profile json,
    cancel_reason character varying
);
CREATE TABLE instr.sql_statements (
    statement_id character varying NOT NULL,
    session_id character varying NOT NULL,
    sql_text character varying NOT NULL,
    statement_kind character varying,
    is_internal boolean NOT NULL,
    prepare_success boolean NOT NULL,
    prepare_error character varying,
    created_time timestamp with time zone NOT NULL,
    query_tag json
);
CREATE VIEW instr.execution_details AS
 SELECT e.execution_id,
    e.statement_id,
    st.session_id,
    s.instance_id,
    st.sql_text,
    e.bind_parameters,
    e.execution_start_time,
    e.execution_end_time,
    e.enqueue_time,
        CASE
            WHEN (e.enqueue_time IS NOT NULL) THEN ((EXTRACT(epoch FROM (e.execution_start_time - e.enqueue_time)) * (1000)::numeric))::bigint
            ELSE NULL::bigint
        END AS queue_wait_ms,
    e.rows_fetched,
    e.status,
    e.error_message,
    e.duration_ms,
    e.query_profile,
    s.username,
    s.auth_method,
    s.peer,
    st.query_tag,
    s.session_tag,
    e.fetch_start_time,
    e.fetch_end_time,
    e.cursor_close_time,
    e.total_duration_ms,
    e.cancel_reason
   FROM ((instr.sql_executions e
     JOIN instr.sql_statements st ON (((e.statement_id)::text = (st.statement_id)::text)))
     JOIN instr.sessions s ON (((st.session_id)::text = (s.session_id)::text)));
CREATE VIEW instr.session_activity AS
 SELECT i.instance_id,
    i.hardcharger_version,
    i.duckdb_version,
    i.arrow_version,
    i.hostname,
    i.hostname_arg,
    i.server_ip,
    i.port,
    i.database_path,
    i.start_time AS instance_start_time,
    i.stop_time AS instance_stop_time,
    i.status AS instance_status,
    i.stop_reason AS instance_stop_reason,
    i.instance_tag,
    s.session_id,
    s.username,
    s.role,
    s.auth_method,
    s.peer,
    s.start_time AS session_start_time,
    s.stop_time AS session_stop_time,
    s.status AS session_status,
    s.stop_reason AS session_stop_reason,
    s.session_tag,
    st.statement_id,
    st.sql_text,
    st.created_time AS statement_created_time,
    e.execution_id,
    e.bind_parameters,
    e.execution_start_time,
    e.execution_end_time,
    e.rows_fetched,
    e.status AS execution_status,
    e.error_message,
    e.duration_ms,
    e.query_profile,
    st.query_tag,
    i.cluster_id,
    e.fetch_start_time,
    e.fetch_end_time,
    e.cursor_close_time,
    e.total_duration_ms,
    e.cancel_reason
   FROM (((instr.instances i
     LEFT JOIN instr.sessions s ON ((i.instance_id = s.instance_id)))
     LEFT JOIN instr.sql_statements st ON (((s.session_id)::text = (st.session_id)::text)))
     LEFT JOIN instr.sql_executions e ON (((st.statement_id)::text = (e.statement_id)::text)));
CREATE VIEW instr.session_stats AS
 SELECT s.session_id,
    s.instance_id,
    s.username,
    s.role,
    s.auth_method,
    s.peer,
    s.start_time,
    s.stop_time,
    s.status AS session_status,
    count(DISTINCT st.statement_id) AS total_statements,
    count(e.execution_id) AS total_executions,
    sum(
        CASE
            WHEN ((e.status)::text = 'success'::text) THEN 1
            ELSE 0
        END) AS successful_executions,
    sum(
        CASE
            WHEN ((e.status)::text = 'error'::text) THEN 1
            ELSE 0
        END) AS failed_executions,
    sum(
        CASE
            WHEN ((e.status)::text = 'timeout'::text) THEN 1
            ELSE 0
        END) AS timed_out_executions,
    sum(
        CASE
            WHEN ((e.status)::text = 'cancelled'::text) THEN 1
            ELSE 0
        END) AS cancelled_executions,
    sum(e.rows_fetched) AS total_rows_fetched,
    avg(e.duration_ms) AS avg_duration_ms,
    max(e.duration_ms) AS max_duration_ms,
    avg(e.total_duration_ms) AS avg_total_duration_ms,
    max(e.total_duration_ms) AS max_total_duration_ms
   FROM ((instr.sessions s
     LEFT JOIN instr.sql_statements st ON (((s.session_id)::text = (st.session_id)::text)))
     LEFT JOIN instr.sql_executions e ON (((st.statement_id)::text = (e.statement_id)::text)))
  GROUP BY s.session_id, s.instance_id, s.username, s.role, s.auth_method, s.peer, s.start_time, s.stop_time, s.status;
INSERT INTO hardcharger_rbac.memberships (member_kind, member_id, role_id, admin_option, granted_by) VALUES ('user', 'fa09ad49-a8b5-4dec-aca2-47ae556877d4', '149971ed-f91b-4678-a3d2-a657af122b6f', false, '');
INSERT INTO hardcharger_rbac.meta (key, value) VALUES ('schema_version', '1');
INSERT INTO hardcharger_rbac.meta (key, value) VALUES ('storage_privileges_split', '1');
INSERT INTO hardcharger_rbac.meta (key, value) VALUES ('data_version', '5');
INSERT INTO hardcharger_rbac.object_grants (grant_id, role_id, scope, catalog_name, schema_path, object_name, privilege, columns, grant_option, granted_by) VALUES ('4ae7463c-c852-4d27-8db3-82f79ca883eb', '149971ed-f91b-4678-a3d2-a657af122b6f', 'schema', 'memory', '["main"]', '', 'SELECT', '[]', false, '');
INSERT INTO hardcharger_rbac.roles (role_id, name, name_key, builtin) VALUES ('public', 'PUBLIC', 'public', true);
INSERT INTO hardcharger_rbac.roles (role_id, name, name_key, builtin) VALUES ('149971ed-f91b-4678-a3d2-a657af122b6f', 'analysts', 'analysts', false);
INSERT INTO hardcharger_rbac.users (user_id, name, name_key, password_hash, enabled) VALUES ('fa09ad49-a8b5-4dec-aca2-47ae556877d4', 'reader', 'reader', 'pbkdf2-sha256$600000$s28NKNzYR5XTKfO7jLU1Uw==$RURFU8o854/FjWacNa7WtWAZZQ2/W4wcT4QZDyOt64o=', true);
INSERT INTO instr.instances (instance_id, cluster_id, hardcharger_version, duckdb_version, arrow_version, hostname, hostname_arg, server_ip, port, database_path, tls_enabled, tls_cert_path, tls_key_path, mtls_required, mtls_ca_cert_path, readonly, os_platform, os_name, os_version, cpu_arch, cpu_model, cpu_count, memory_total_bytes, start_time, stop_time, status, stop_reason, instance_tag) VALUES ('ce06b0a8-ae15-4862-844c-53085b422c2c', NULL, '2.13.4', 'v2.0.1', '26.0.1', 'fixture', '127.0.0.1', NULL, 20005, NULL, false, NULL, NULL, false, NULL, false, 'Darwin', NULL, NULL, 'arm64', NULL, 18, NULL, '2026-11-21 12:43:34.513504+00', '2026-11-21 12:43:35.265382+00', 'stopped', 'graceful', NULL);
INSERT INTO instr.sessions (session_id, instance_id, username, role, auth_method, peer, peer_identity, user_agent, connection_protocol, start_time, stop_time, status, stop_reason, session_tag) VALUES ('s_vq77wpnlgh7jz752ugb4dzdwslvt3wsv', 'ce06b0a8-ae15-4862-844c-53085b422c2c', 'reader', 'user', 'password', '', NULL, NULL, 'http', '2026-11-21 12:43:35.152365+00', '2026-11-21 12:43:35.154964+00', 'closed', 'closed', NULL);
INSERT INTO instr.sessions (session_id, instance_id, username, role, auth_method, peer, peer_identity, user_agent, connection_protocol, start_time, stop_time, status, stop_reason, session_tag) VALUES ('s_ky4hd6pfbm22buutz6da43cnikqkfxmz', 'ce06b0a8-ae15-4862-844c-53085b422c2c', 'admin', 'admin', 'password', '', NULL, NULL, 'http', '2026-11-21 12:43:34.706138+00', '2026-11-21 12:43:35.155329+00', 'closed', 'closed', NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_k2n25d2r63czki7jwiexy4zbre6skqau', 'q_k2n25d2r63czki7jwiexy4zbre6skqau', NULL, '2026-11-21 12:43:34.708348+00', '2026-11-21 12:43:34.708482+00', NULL, '2026-11-21 12:43:34.70853+00', '2026-11-21 12:43:34.708544+00', '2026-11-21 12:43:34.708567+00', 1, 'success', NULL, 0, 0, NULL, NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_vyo5misjb6pad5gshorci2acqtcte6wk', 'q_vyo5misjb6pad5gshorci2acqtcte6wk', NULL, '2026-11-21 12:43:34.711849+00', '2026-11-21 12:43:34.847121+00', NULL, '2026-11-21 12:43:34.847161+00', '2026-11-21 12:43:34.847165+00', '2026-11-21 12:43:34.847186+00', 1, 'success', NULL, 136, 136, NULL, NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_bcmrh3xk7ucjfgok7jcby55j6m3jfuxu', 'q_bcmrh3xk7ucjfgok7jcby55j6m3jfuxu', NULL, '2026-11-21 12:43:34.848551+00', '2026-11-21 12:43:34.933691+00', NULL, '2026-11-21 12:43:34.933727+00', '2026-11-21 12:43:34.933737+00', '2026-11-21 12:43:34.933759+00', 1, 'success', NULL, 85, 85, NULL, NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_cdr5ia2mwquvs4g2rcvru5dymffa363s', 'q_cdr5ia2mwquvs4g2rcvru5dymffa363s', NULL, '2026-11-21 12:43:34.935313+00', '2026-11-21 12:43:35.021452+00', NULL, '2026-11-21 12:43:35.021484+00', '2026-11-21 12:43:35.021488+00', '2026-11-21 12:43:35.021506+00', 1, 'success', NULL, 86, 86, NULL, NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_6nw45v776wr3o77pl2rzirl62slp7dth', 'q_6nw45v776wr3o77pl2rzirl62slp7dth', NULL, '2026-11-21 12:43:35.022818+00', '2026-11-21 12:43:35.101524+00', NULL, '2026-11-21 12:43:35.101559+00', '2026-11-21 12:43:35.101564+00', '2026-11-21 12:43:35.101585+00', 1, 'success', NULL, 79, 79, NULL, NULL);
INSERT INTO instr.sql_executions (execution_id, statement_id, bind_parameters, execution_start_time, execution_end_time, enqueue_time, fetch_start_time, fetch_end_time, cursor_close_time, rows_fetched, status, error_message, duration_ms, total_duration_ms, query_profile, cancel_reason) VALUES ('q_t662acigbguiuip7ypldlp4go4lxmf7i', 'q_t662acigbguiuip7ypldlp4go4lxmf7i', NULL, '2026-11-21 12:43:35.154196+00', '2026-11-21 12:43:35.154315+00', NULL, '2026-11-21 12:43:35.154346+00', '2026-11-21 12:43:35.154358+00', '2026-11-21 12:43:35.154378+00', 1, 'success', NULL, 0, 0, NULL, NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_k2n25d2r63czki7jwiexy4zbre6skqau', 's_ky4hd6pfbm22buutz6da43cnikqkfxmz', 'SELECT HARDCHARGER_VERSION()', 'statement', false, true, NULL, '2026-11-21 12:43:34.707993+00', NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_vyo5misjb6pad5gshorci2acqtcte6wk', 's_ky4hd6pfbm22buutz6da43cnikqkfxmz', '[REDACTED: user DDL]', 'statement', false, true, NULL, '2026-11-21 12:43:34.711741+00', NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_bcmrh3xk7ucjfgok7jcby55j6m3jfuxu', 's_ky4hd6pfbm22buutz6da43cnikqkfxmz', 'CREATE ROLE analysts', 'statement', false, true, NULL, '2026-11-21 12:43:34.848252+00', NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_cdr5ia2mwquvs4g2rcvru5dymffa363s', 's_ky4hd6pfbm22buutz6da43cnikqkfxmz', 'GRANT SELECT ON SCHEMA main TO analysts', 'statement', false, true, NULL, '2026-11-21 12:43:34.93478+00', NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_6nw45v776wr3o77pl2rzirl62slp7dth', 's_ky4hd6pfbm22buutz6da43cnikqkfxmz', 'GRANT analysts TO reader', 'statement', false, true, NULL, '2026-11-21 12:43:35.022489+00', NULL);
INSERT INTO instr.sql_statements (statement_id, session_id, sql_text, statement_kind, is_internal, prepare_success, prepare_error, created_time, query_tag) VALUES ('q_t662acigbguiuip7ypldlp4go4lxmf7i', 's_vq77wpnlgh7jz752ugb4dzdwslvt3wsv', 'SELECT 17 AS released_probe', 'statement', false, true, NULL, '2026-11-21 12:43:35.153828+00', NULL);
ALTER TABLE ONLY hardcharger_rbac.catalog_tenants
    ADD CONSTRAINT catalog_tenants_pkey PRIMARY KEY (catalog_key);
ALTER TABLE ONLY hardcharger_rbac.group_mappings
    ADD CONSTRAINT group_mappings_issuer_group_name_role_id_key UNIQUE (issuer, group_name, role_id);
ALTER TABLE ONLY hardcharger_rbac.group_mappings
    ADD CONSTRAINT group_mappings_pkey PRIMARY KEY (mapping_id);
ALTER TABLE ONLY hardcharger_rbac.mask_bindings
    ADD CONSTRAINT mask_bindings_pkey PRIMARY KEY (table_key, column_key);
ALTER TABLE ONLY hardcharger_rbac.masking_policies
    ADD CONSTRAINT masking_policies_name_key_key UNIQUE (name_key);
ALTER TABLE ONLY hardcharger_rbac.masking_policies
    ADD CONSTRAINT masking_policies_pkey PRIMARY KEY (policy_id);
ALTER TABLE ONLY hardcharger_rbac.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (member_kind, member_id, role_id);
ALTER TABLE ONLY hardcharger_rbac.meta
    ADD CONSTRAINT meta_pkey PRIMARY KEY (key);
ALTER TABLE ONLY hardcharger_rbac.object_grants
    ADD CONSTRAINT object_grants_pkey PRIMARY KEY (grant_id);
ALTER TABLE ONLY hardcharger_rbac.owners
    ADD CONSTRAINT owners_pkey PRIMARY KEY (object_key);
ALTER TABLE ONLY hardcharger_rbac.principal_tenants
    ADD CONSTRAINT principal_tenants_pkey PRIMARY KEY (principal_kind, principal_id);
ALTER TABLE ONLY hardcharger_rbac.roles
    ADD CONSTRAINT roles_name_key_key UNIQUE (name_key);
ALTER TABLE ONLY hardcharger_rbac.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);
ALTER TABLE ONLY hardcharger_rbac.row_policies
    ADD CONSTRAINT row_policies_pkey PRIMARY KEY (policy_id);
ALTER TABLE ONLY hardcharger_rbac.scoped_tokens
    ADD CONSTRAINT scoped_tokens_pkey PRIMARY KEY (token_id);
ALTER TABLE ONLY hardcharger_rbac.scoped_tokens
    ADD CONSTRAINT scoped_tokens_user_id_name_key_key UNIQUE (user_id, name_key);
ALTER TABLE ONLY hardcharger_rbac.storage_privileges
    ADD CONSTRAINT storage_privileges_pkey PRIMARY KEY (role_id, privilege, location, granted_by);
ALTER TABLE ONLY hardcharger_rbac.system_privileges
    ADD CONSTRAINT system_privileges_pkey PRIMARY KEY (role_id, privilege, granted_by);
ALTER TABLE ONLY hardcharger_rbac.tenants
    ADD CONSTRAINT tenants_name_key_key UNIQUE (name_key);
ALTER TABLE ONLY hardcharger_rbac.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);
ALTER TABLE ONLY hardcharger_rbac.user_attributes
    ADD CONSTRAINT user_attributes_pkey PRIMARY KEY (user_id, attribute);
ALTER TABLE ONLY hardcharger_rbac.users
    ADD CONSTRAINT users_name_key_key UNIQUE (name_key);
ALTER TABLE ONLY hardcharger_rbac.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);
ALTER TABLE ONLY instr.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (instance_id);
ALTER TABLE ONLY instr.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session_id);
ALTER TABLE ONLY instr.sql_executions
    ADD CONSTRAINT sql_executions_pkey PRIMARY KEY (execution_id);
ALTER TABLE ONLY instr.sql_statements
    ADD CONSTRAINT sql_statements_pkey PRIMARY KEY (statement_id);
CREATE INDEX sessions_instance_id ON instr.sessions USING btree (instance_id);
CREATE INDEX sql_executions_start_time ON instr.sql_executions USING btree (execution_start_time);
CREATE INDEX sql_executions_statement_id ON instr.sql_executions USING btree (statement_id);
CREATE INDEX sql_statements_created_time ON instr.sql_statements USING btree (created_time);
CREATE INDEX sql_statements_session_id ON instr.sql_statements USING btree (session_id);
ALTER TABLE ONLY instr.sessions
    ADD CONSTRAINT sessions_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES instr.instances(instance_id) ON DELETE CASCADE;
ALTER TABLE ONLY instr.sql_executions
    ADD CONSTRAINT sql_executions_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES instr.sql_statements(statement_id) ON DELETE CASCADE;
ALTER TABLE ONLY instr.sql_statements
    ADD CONSTRAINT sql_statements_session_id_fkey FOREIGN KEY (session_id) REFERENCES instr.sessions(session_id) ON DELETE CASCADE;
